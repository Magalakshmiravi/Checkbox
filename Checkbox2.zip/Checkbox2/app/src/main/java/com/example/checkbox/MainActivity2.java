package com.example.checkbox;

import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
LinearLayout parent;
//Button btn_check;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        parent = (LinearLayout)findViewById(R.id.ll_parent);
       // btn_check=(Button)findViewById(R.id.btn_check);

        String[] strtext = {"\n\nImportance of Listening Skills \n" ,
                "\nDifference between Listening and Hearing \n" ,
                "\n Active Listening\n " ,
                        " \nBarriers to Listening\n" ,
                " \nListening comprehension focusing on varying elements of vocabulary and structure\n " ,
                        " Pronunciation\n" ,
                                "\n Self Introduction\n " ,
                                " \nDescriptive Language \n" ,
                "\nMeanings \n" ,
                "\n Affixes\n" ,
                " \n Prefixes \n" ,
                "\nVocabulary building for places and people verb forms \n",
                "\nReading Skills \n" ,
                "\nSub skills of Reading\n" ,
                "\n Skimming and Scanning\n" ,
                "\n Descriptive writing\n" ,
                "\nPeople description \n" ,
                "\n Letter Writing \n" ,
                " \nPersonal: To family \n" ,
                " \nTo friends \n",
                "\nAsking for information/ giving suggestions\n" ,
                "\n Social conversation – Introducing and Greeting\n\n"};
        final ArrayList<String>list_checkboxes=new ArrayList<>();

        for (int i = 0; i<22; i++)
        {
            CheckBox ch1= new CheckBox((getApplicationContext()));
            ch1.setText(strtext[i]);
            parent.addView(ch1);
            ch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        list_checkboxes.add(buttonView.getText().toString());
                    }
                    else
                    {
                        list_checkboxes.remove(list_checkboxes.indexOf(buttonView.getText().toString()));
                    }
                }
            });
        }




    }
}